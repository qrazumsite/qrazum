
/* ============ Q-РАЗУМ · ЛОГИКА ============ */
var DB_KEY='qrazum_db_v1', SES_KEY='qrazum_session_v1';
var COMMITTEES=[
 {id:'SMM',name:'SMM',tasks:['Вести соцсети движения','Придумывать посты и рубрики','Анализировать охваты'],projects:['Рубрика «Идея недели»','Анонсы мероприятий'],curator:'Назначается владельцем',desc:'Голос движения в интернете: делаем так, чтобы о Q-Разум узнал весь Ульяновск.'},
 {id:'Инвент-менеджмент',name:'Инвент-менеджмент',tasks:['Управлять ресурсами команды','Следить за оборудованием и реквизитом','Готовить базы к мероприятиям'],projects:['Единый склад движения'],curator:'Назначается владельцем',desc:'Всё, без чего команда не поедет: техника, реквизит, материалы — под контролем.'},
 {id:'Волонтёрство',name:'Волонтёрство',tasks:['Организовывать добрые дела','Работать с партнёрами','Собирать команду на акции'],projects:['Городские акции помощи'],curator:'Назначается владельцем',desc:'Меняем мир через дела: помогаем тем, кто рядом.'},
 {id:'Журналистика',name:'Журналистика',tasks:['Писать статьи и интервью','Снимать и монтировать','Вести летопись движения'],projects:['Медиапроект «Q-Голос»'],curator:'Назначается владельцем',desc:'Находим истории и рассказываем о них всему движению.'}
];
function seed(){return{
 users:[
  {id:1,email:'qrazym24@gmail.com',pass:'owner-qrazum',name:'Владелец Q-Разум',role:'owner',status:'active',created:'2026-10-01'},
  {id:2,email:'staff@qrazum.ru',pass:'staff-qrazum',name:'Сотрудник администрации',role:'staff',status:'active',created:'2026-10-01'}
 ],
 apps:[],news:[
  {id:1,tag:'info',title:'Q-Разум открывает набор в комитеты',text:'Мы ищем тех, кто думает громко и действует смело. Выбирайте направление — журналистика, SMM, инвент-менеджмент или волонтёрство — и подавайте заявку.',date:'2026-10-05',author:'Владелец Q-Разум'},
  {id:2,tag:'events',title:'Первый форум движения',text:'Скоро встреча всех комитетов: знакомство, планы и квест по городу. Следите за разделом «Мероприятия».',date:'2026-10-10',author:'Владелец Q-Разум'}
 ],
 events:[
  {id:1,title:'Форум Q-Разум: знакомство комитетов',desc:'Большая встреча движения: представление комитетов, командные задания и планы на сезон.',date:'2026-11-08 14:00',place:'Ульяновск, точка кипения',committee:'Все комитеты',seats:60,status:'набор открыт',members:[]}
 ],
 notifs:[],nextId:100
};}
function db(){var raw=null;try{raw=localStorage.getItem(DB_KEY)}catch(e){}
 if(!raw){var d=seed();try{localStorage.setItem(DB_KEY,JSON.stringify(d))}catch(e){}return d}
 try{return JSON.parse(raw)}catch(e){return seed()}}
function save(d){try{localStorage.setItem(DB_KEY,JSON.stringify(d))}catch(e){}}
function nextId(d){d.nextId=(d.nextId||100)+1;return d.nextId}
function me(){var s=null;try{s=JSON.parse(localStorage.getItem(SES_KEY)||'null')}catch(e){}
 if(!s)return null;var d=db();return d.users.find(function(u){return u.id===s.id&&u.status==='active'})||null}
function login(id){try{localStorage.setItem(SES_KEY,JSON.stringify({id:id}))}catch(e){}}
function logout(){try{localStorage.removeItem(SES_KEY)}catch(e){}}
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
function now(){return new Date().toISOString().slice(0,10)}
function notify(d,userId,text){d.notifs.push({id:nextId(d),userId:userId,text:text,date:now(),read:false})}
function approvedCount(){var d=db();return d.apps.filter(function(a){return a.type==='join'&&a.status==='approved'}).length}
function tagName(t){return t==='events'?'Мероприятия':t==='projects'?'Проекты':'Инфоблок'}

function initNav(){
 var b=document.querySelector('.burger'),n=document.querySelector('.topnav');
 if(b&&n)b.addEventListener('click',function(){n.classList.toggle('open')});
 var m=me();
 var el=document.getElementById('auth-links');
 if(el){el.innerHTML=m
  ?'<a href="account.html">Кабинет: '+esc(m.name.split(' ')[0])+'</a>'+(m.role!=='member'?'<a href="admin.html">Панель управления</a>':'')
  :'<a href="account.html">Вход</a><a href="account.html?mode=register">Регистрация</a>'}
}

function pageHome(){
 var s=document.getElementById('stat-members');
 if(s)s.textContent=approvedCount();
 var nl=document.getElementById('home-news');
 if(nl){var d=db();nl.innerHTML=d.news.slice(-3).reverse().map(function(n){
  return '<div class="card"><span class="tag">'+tagName(n.tag)+'</span><h3>'+esc(n.title)+'</h3><p class="meta">'+esc(n.text.slice(0,120))+'…</p><div class="foot"><span class="meta">'+esc(n.date)+'</span><a class="btn ghost sm" href="news.html">Все новости →</a></div></div>'}).join('')||'<div class="empty">Новостей пока нет</div>'}
}

function pageCommittees(){
 var g=document.getElementById('com-grid');if(!g)return;
 g.innerHTML=COMMITTEES.map(function(c,i){
  return '<div class="card"><span class="num">0'+(i+1)+' / КОМИТЕТ</span><h3>'+esc(c.name)+'</h3><p class="meta">'+esc(c.desc)+'</p><p><b>Задачи:</b> '+esc(c.tasks.join('; '))+'</p><p><b>Проекты:</b> '+esc(c.projects.join('; '))+'</p><p class="meta"><b>Куратор:</b> '+esc(c.curator)+'</p><div class="foot"><a class="btn sm" href="apply.html?com='+encodeURIComponent(c.id)+'">Хочу в комитет →</a><span></span></div></div>'}).join('');
}

function pageNews(){
 var d=db(),list=document.getElementById('news-list');if(!list)return;
 function render(tag){
  var items=d.news.slice().reverse().filter(function(n){return !tag||n.tag===tag});
  list.innerHTML=items.map(function(n){return '<div class="item"><div class="head"><b>'+esc(n.title)+'</b><span class="tag">'+tagName(n.tag)+'</span></div><p class="meta" style="margin:8px 0">'+esc(n.text)+'</p><div class="meta">'+esc(n.date)+' · '+esc(n.author)+'</div></div>'}).join('')||'<div class="empty">Пока пусто</div>'}
 render('');
 document.querySelectorAll('.tab[data-tag]').forEach(function(t){t.addEventListener('click',function(){
  document.querySelectorAll('.tab[data-tag]').forEach(function(x){x.classList.remove('active')});
  t.classList.add('active');render(t.dataset.tag)})});
}

function pageEvents(){
 var d=db(),list=document.getElementById('events-list');if(!list)return;
 var u=me();
 list.innerHTML=d.events.map(function(e){
  var joined=u&&e.members.indexOf(u.id)>=0,full=e.members.length>=e.seats;
  var btn=joined?'<span class="badge approved">Вы участвуете</span>':full?'<span class="meta">Мест нет</span>':u?'<button class="btn sm" data-join="'+e.id+'">Я участвую</button>':'<a class="btn ghost sm" href="account.html">Войдите, чтобы участвовать</a>';
  return '<div class="card"><span class="num">'+esc(e.date)+' · '+esc(e.place)+'</span><h3>'+esc(e.title)+'</h3><p class="meta">'+esc(e.desc)+'</p><p class="meta"><b>Комитет:</b> '+esc(e.committee)+' · <b>Мест:</b> '+(e.seats-e.members.length)+' из '+e.seats+'</p><div class="foot">'+btn+'<span class="meta">Участников: '+e.members.length+'</span></div></div>'}).join('')||'<div class="empty">Мероприятий пока нет</div>';
 list.querySelectorAll('[data-join]').forEach(function(b){b.addEventListener('click',function(){
  var dd=db(),u2=me();if(!u2)return;
  var e=dd.events.find(function(x){return x.id==b.dataset.join});
  if(!e||e.members.indexOf(u2.id)>=0||e.members.length>=e.seats)return;
  e.members.push(u2.id);notify(dd,u2.id,'Вы записаны на «'+e.title+'» — '+e.date+'.');save(dd);pageEvents();
  var n=document.getElementById('join-ok');if(n)n.classList.add('show')})});
}

function pageApply(){
 var u=me();
 var sel2=document.getElementById('f-committee');
 var q=new URLSearchParams(location.search).get('com');
 if(sel2&&q)sel2.value=q;
 var nm=document.getElementById('f-name'),em=document.getElementById('f-contact');
 if(u&&nm)nm.value=u.name;if(u&&em)em.value=u.email;
 var form=document.getElementById('apply-form');if(!form)return;
 form.addEventListener('submit',function(ev){ev.preventDefault();
  var err=document.getElementById('apply-err');err.textContent='';
  var name=nm.value.trim(),contact=em.value.trim(),city=document.getElementById('f-city').value.trim(),
  age=document.getElementById('f-age').value,com=sel2.value,mot=document.getElementById('f-mot').value.trim(),
  captcha=document.getElementById('f-captcha').value.trim();
  if(name.length<3||!contact||!city||!mot){err.textContent='Заполните все поля: имя, контакт, город и мотивация.';return}
  if(age&&(+age<12||+age>99)){err.textContent='Укажите возраст от 12 до 99.';return}
  if(captcha!=='7'){err.textContent='Проверка от спама: сколько будет 3 + 4?';return}
  var d=db();u=me();
  d.apps.push({id:nextId(d),type:'join',userId:u?u.id:null,name:name,email:contact,age:age,city:city,committee:com,motivation:mot,status:'new',comment:'',date:now()});
  if(u)notify(d,u.id,'Заявка в комитет «'+com+'» принята и ждёт рассмотрения.');
  save(d);form.reset();err.textContent='';var ok=document.getElementById('apply-ok');if(ok)ok.classList.add('show');
  form.style.display='none'});
}

function pageAccount(){
 var box=document.getElementById('auth-box'),cab=document.getElementById('cabinet');
 function renderCab(u){
  box.style.display='none';cab.style.display='block';
  document.getElementById('c-name').textContent=u.name;
  document.getElementById('c-role').textContent=u.role==='owner'?'Владелец':u.role==='staff'?'Сотрудник администрации':'Участник';
  document.getElementById('c-email').textContent=u.email;
  var d=db();
  document.getElementById('c-apps').innerHTML=d.apps.filter(function(a){return a.userId===u.id||(a.email&&a.email===u.email)}).map(function(a){
   return '<div class="item"><div class="head"><b>'+(a.type==='join'?'Заявка в комитет':'Заявка в администрацию')+': '+esc(a.committee||'—')+'</b><span class="badge '+a.status+'">'+({new:'На рассмотрении',approved:'Принята',rejected:'Отклонена'})[a.status]+'</span></div><div class="meta">Подана: '+esc(a.date)+(a.comment?' · Ответ: '+esc(a.comment):'')+'</div></div>'}).join('')||'<div class="empty">Заявок нет</div>';
  var myEv=d.events.filter(function(e){return e.members.indexOf(u.id)>=0});
  document.getElementById('c-events').innerHTML=myEv.map(function(e){return '<div class="item notif"><b>'+esc(e.title)+'</b><div class="meta">'+esc(e.date)+' · '+esc(e.place)+'</div></div>'}).join('')||'<div class="empty">Вы пока не записаны ни на одно мероприятие</div>';
  document.getElementById('c-notifs').innerHTML=d.notifs.filter(function(n){return n.userId===u.id}).map(function(n){return '<div class="item notif"><div class="meta">'+esc(n.date)+'</div>'+esc(n.text)+'</div>'}).join('')||'<div class="empty">Уведомлений нет</div>';
  if(u.role!=='member')document.getElementById('c-admin-link').style.display='inline-flex';
 }
 var u=me();
 if(u&&cab)renderCab(u);
 var mode=new URLSearchParams(location.search).get('mode');
 var tabIn=document.getElementById('tab-in'),tabUp=document.getElementById('tab-up');
 function show(inMode){if(inMode){tabIn.style.display='block';tabUp.style.display='none'}else{tabIn.style.display='none';tabUp.style.display='block'}}
 if(!u)show(mode!=='register');
 var sw1=document.getElementById('sw-up'),sw2=document.getElementById('sw-in');
 if(sw1)sw1.addEventListener('click',function(){show(false)});
 if(sw2)sw2.addEventListener('click',function(){show(true)});
 var fIn=document.getElementById('login-form');
 if(fIn)fIn.addEventListener('submit',function(ev){ev.preventDefault();
  var d=db(),email=document.getElementById('l-email').value.trim().toLowerCase(),pass=document.getElementById('l-pass').value;
  var usr=d.users.find(function(x){return x.email.toLowerCase()===email&&x.pass===pass});
  if(!usr){document.getElementById('l-err').textContent='Неверный email или пароль.';return}
  if(usr.status==='blocked'){document.getElementById('l-err').textContent='Аккаунт заблокирован.';return}
  login(usr.id);save(d);location.reload()});
 var fUp=document.getElementById('reg-form');
 if(fUp)fUp.addEventListener('submit',function(ev){ev.preventDefault();
  var d=db(),err=document.getElementById('r-err');err.textContent='';
  var name=document.getElementById('r-name').value.trim(),email=document.getElementById('r-email').value.trim().toLowerCase(),p1=document.getElementById('r-pass').value,p2=document.getElementById('r-pass2').value;
  if(name.length<3){err.textContent='Укажите имя (минимум 3 символа).';return}
  if(!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)){err.textContent='Введите корректный email.';return}
  if(p1.length<6){err.textContent='Пароль — минимум 6 символов.';return}
  if(p1!==p2){err.textContent='Пароли не совпадают.';return}
  if(d.users.some(function(x){return x.email.toLowerCase()===email})){err.textContent='Такой email уже зарегистрирован.';return}
  var nu={id:nextId(d),email:email,pass:p1,name:name,role:'member',status:'active',created:now()};
  d.users.push(nu);save(d);login(nu.id);location.href='account.html'});
 var out=document.getElementById('btn-logout');
 if(out)out.addEventListener('click',function(){logout();location.href='index.html'});
}

function pageAdmin(){
 var loginBox=document.getElementById('admin-login'),panel=document.getElementById('admin-panel');
 if(!loginBox)return;
 function open(u){loginBox.style.display='none';panel.style.display='block';buildNav(u);show('dash')}
 function buildNav(u){
  var links=[['dash','Дашборд'],['apps','Заявки'],['news','Новости'],['coms','Комитеты'],['evs','Мероприятия']];
  if(u.role==='owner')links.push(['users','Пользователи']);
  var n=document.getElementById('admin-nav');n.innerHTML='';
  links.forEach(function(l){var a=document.createElement('a');a.textContent=l[1];a.dataset.pane=l[0];
   a.addEventListener('click',function(){n.querySelectorAll('a').forEach(function(x){x.classList.remove('active')});a.classList.add('active');show(l[0])});n.appendChild(a)});
  var lo=document.createElement('a');lo.textContent='Выйти';lo.addEventListener('click',function(){logout();location.href='index.html'});n.appendChild(lo);
 }
 function show(p){document.querySelectorAll('.pane').forEach(function(x){x.classList.remove('active')});
  var el=document.getElementById('pane-'+p);if(el)el.classList.add('active');if(p==='dash')dash();if(p==='apps')appsP();if(p==='news')newsP();if(p==='coms')comsP();if(p==='evs')evsP();if(p==='users')usersP()}
 var u=me();
 if(u&&u.role!=='member')open(u);
 var f=document.getElementById('admin-form');
 if(f)f.addEventListener('submit',function(ev){ev.preventDefault();
  var d=db(),email=document.getElementById('a-email').value.trim().toLowerCase(),pass=document.getElementById('a-pass').value;
  var usr=d.users.find(function(x){return x.email.toLowerCase()===email&&x.pass===pass&&(x.role==='staff'||x.role==='owner')});
  if(!usr){document.getElementById('a-err').textContent='Доступ только для сотрудников и владельца.';return}
  login(usr.id);open(usr)});
 function dash(){
  var d=db();
  document.getElementById('d-users').textContent=d.users.length;
  document.getElementById('d-apps').textContent=d.apps.filter(function(a){return a.status==='new'}).length;
  document.getElementById('d-members').textContent=approvedCount();
  document.getElementById('d-events').textContent=d.events.length;
 }
 function appsP(){
  var d=db(),t=document.getElementById('apps-tbl');
  t.innerHTML='<tr><th>Тип</th><th>Заявитель</th><th>Комитет</th><th>Мотивация</th><th>Статус</th><th>Действия</th></tr>'+
   d.apps.slice().reverse().map(function(a){
    return '<tr><td>'+(a.type==='join'?'Вступление':'Администрация')+'</td><td>'+esc(a.name)+'<div class="meta">'+esc(a.email)+(a.city?' · '+esc(a.city):'')+(a.age?' · '+a.age:'')+'</div></td><td>'+esc(a.committee||'—')+'</td><td class="meta">'+esc(a.motivation||'')+'</td><td><span class="badge '+a.status+'">'+({new:'новая',approved:'принята',rejected:'отклонена'})[a.status]+'</span></td>'+
    '<td class="acts">'+(a.status==='new'?'<button class="btn sm" data-ok="'+a.id+'">Принять</button><button class="btn ghost sm" data-no="'+a.id+'">Отклонить</button>':esc(a.comment||'—'))+'</td></tr>'}).join('')||'<tr><td colspan="6" class="empty">Заявок нет</td></tr>';
  t.querySelectorAll('[data-ok]').forEach(function(b){b.addEventListener('click',function(){decide(+b.dataset.ok,'approved')})});
  t.querySelectorAll('[data-no]').forEach(function(b){b.addEventListener('click',function(){decide(+b.dataset.no,'rejected')})});
 }
 function decide(id,st){
  var d=db(),a=d.apps.find(function(x){return x.id===id});if(!a||a.status!=='new')return;
  var c=prompt('Комментарий к решению (необязательно):')||'';
  a.status=st;a.comment=c;
  var usr=a.userId?d.users.find(function(x){return x.id===a.userId}):null;
  if(st==='approved'&&a.type==='staff'){if(usr)usr.role='staff'}
  if(usr)notify(d,usr.id,a.type==='join'?'Ваша заявка в комитет «'+a.committee+'» '+(st==='approved'?'принята':'отклонена')+(c?'. Комментарий: '+c:''):'Ваша заявка в администрацию '+(st==='approved'?'одобрена':'отклонена')+(c?'. Комментарий: '+c:''));
  save(d);appsP();dash();
 }
 function newsP(){
  var d=db();var t=document.getElementById('news-adm-tbl');
  function list(){t.innerHTML='<tr><th>Заголовок</th><th>Тема</th><th>Дата</th><th>Удалить</th></tr>'+d.news.slice().reverse().map(function(n){return '<tr><td>'+esc(n.title)+'</td><td>'+tagName(n.tag)+'</td><td class="meta">'+esc(n.date)+'</td><td><button class="btn danger sm" data-del="'+n.id+'">×</button></td></tr>'}).join('')||'<tr><td colspan="4" class="empty">Пусто</td></tr>';
   t.querySelectorAll('[data-del]').forEach(function(b){b.addEventListener('click',function(){d.news=d.news.filter(function(x){return x.id!=b.dataset.del});save(d);list()})})}
  list();
  var f=document.getElementById('news-form');
  f.addEventListener('submit',function(ev){ev.preventDefault();
   var title=document.getElementById('n-title').value.trim(),text=document.getElementById('n-text').value.trim(),tag=document.getElementById('n-tag').value;
   if(!title||!text)return;d.news.push({id:nextId(d),tag:tag,title:title,text:text,date:now(),author:me().name});save(d);f.reset();list()});
 }
 function comsP(){
  var c=document.getElementById('coms-box');if(c.dataset.done)return;c.dataset.done='1';
  c.innerHTML=COMMITTEES.map(function(cm){return '<div class="item"><div class="head"><b>'+esc(cm.name)+'</b><span class="meta">ID: '+esc(cm.id)+'</span></div><p class="meta">'+esc(cm.desc)+'</p><p class="meta"><b>Задачи:</b> '+esc(cm.tasks.join('; '))+'</p><div style="margin-top:8px"><input data-curfor="'+esc(cm.id)+'" value="'+esc(cm.curator)+'" style="background:var(--panel2);border:1px solid var(--line);border-radius:8px;padding:8px;color:var(--txt);width:100%"></div><button class="btn sm" data-save="'+esc(cm.id)+'" style="margin-top:8px">Сохранить куратора</button></div>'}).join('');
  c.querySelectorAll('[data-save]').forEach(function(b){b.addEventListener('click',function(){
   var id=b.dataset.save;var inp=c.querySelector('[data-curfor="'+id+'"]');
   var v=inp?inp.value.trim():'';if(!v)return;
   var cm=COMMITTEES.find(function(x){return x.id===id});cm.curator=v;
   alert('Сохранено локально. Куратор: '+v)})});
 }
 function evsP(){
  var d=db(),t=document.getElementById('evs-tbl');
  function list(){t.innerHTML='<tr><th>Название</th><th>Когда</th><th>Мест</th><th>Участников</th><th>Удалить</th></tr>'+d.events.map(function(e){return '<tr><td>'+esc(e.title)+'</td><td class="meta">'+esc(e.date)+' · '+esc(e.place)+'</td><td>'+e.seats+'</td><td>'+e.members.length+'</td><td><button class="btn danger sm" data-del="'+e.id+'">×</button></td></tr>'}).join('')||'<tr><td colspan="5" class="empty">Мероприятий нет</td></tr>';
   t.querySelectorAll('[data-del]').forEach(function(b){b.addEventListener('click',function(){d.events=d.events.filter(function(x){return x.id!=b.dataset.del});save(d);list()})})}
  list();
  var f=document.getElementById('ev-form');
  f.addEventListener('submit',function(ev){ev.preventDefault();
   var ti=document.getElementById('e-title').value.trim(),de=document.getElementById('e-desc').value.trim(),da=document.getElementById('e-date').value.trim(),pl=document.getElementById('e-place').value.trim(),co=document.getElementById('e-com').value,se=+document.getElementById('e-seats').value||20;
   if(!ti||!da)return;d.events.push({id:nextId(d),title:ti,desc:de,date:da,place:pl,committee:co,seats:se,status:'набор открыт',members:[]});
   save(d);f.reset();list()});
 }
 function usersP(){
  var d=db(),t=document.getElementById('users-tbl');
  function list(){t.innerHTML='<tr><th>Email</th><th>Имя</th><th>Роль</th><th>Статус</th><th>Действия</th></tr>'+d.users.map(function(x){return '<tr><td>'+esc(x.email)+'</td><td>'+esc(x.name)+'</td><td>'+({owner:'Владелец',staff:'Сотрудник',member:'Участник'})[x.role]+'</td><td><span class="badge '+x.status+'">'+(x.status==='active'?'активен':'заблокирован')+'</span></td>'+
   '<td class="acts">'+(x.role!=='owner'?'<button class="btn sm" data-role="'+x.id+'">Сделать сотрудником</button><button class="btn ghost sm" data-blk="'+x.id+'">'+(x.status==='active'?'Заблокировать':'Разблокировать')+'</button><button class="btn danger sm" data-del="'+x.id+'">×</button>':'—')+'</td></tr>'}).join('');
   t.querySelectorAll('[data-role]').forEach(function(b){b.addEventListener('click',function(){var x=d.users.find(function(u2){return u2.id==b.dataset.role});x.role='staff';save(d);list()})});
   t.querySelectorAll('[data-blk]').forEach(function(b){b.addEventListener('click',function(){var x=d.users.find(function(u2){return u2.id==b.dataset.blk});x.status=x.status==='active'?'blocked':'active';save(d);list()})});
   t.querySelectorAll('[data-del]').forEach(function(b){b.addEventListener('click',function(){d.users=d.users.filter(function(u2){return u2.id!=b.dataset.del});save(d);list()})})}
  list();
 }
}

document.addEventListener('DOMContentLoaded',function(){
 initNav();
 var p=document.body.dataset.page;
 if(p==='home')pageHome();
 if(p==='committees')pageCommittees();
 if(p==='news')pageNews();
 if(p==='events')pageEvents();
 if(p==='apply')pageApply();
 if(p==='account')pageAccount();
 if(p==='admin')pageAdmin();
});
